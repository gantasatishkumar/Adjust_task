BEGIN;
SET client_min_messages TO 'WARNING';
\set ECHO none
\i sql/min_max_agg.sql
\set ECHO all
RESET client_min_messages;

CREATE TEMPORARY TABLE agg_test (
    val integer
);

INSERT INTO agg_test (val)
VALUES (1), (2), (1), (1), (4), (2), (1), (3), (3);

SELECT min_max(val) FROM agg_test;

ROLLBACK;
