#include "postgres.h"
#include "string.h"
#include <utils/array.h>
#include <utils/lsyscache.h>
#include "fmgr.h"

PG_MODULE_MAGIC;

extern Datum min_max_sfunc(PG_FUNCTION_ARGS);

PG_FUNCTION_INFO_V1(min_max_sfunc);

Datum
min_max_sfunc(PG_FUNCTION_ARGS)
{
	char*	result_str = malloc(100 * sizeof(char));
	int 	min;
	int 	max;
	ArrayType* arr;

	Oid arrElemType; // INT4OID
	int16 arrElemLen; // 4
	bool arrElemTypeByVal; // true - pass by value
	char arrElemTypeAlignmentCode; // alignmentCode

	Datum *arrd;
	bool *nullFlags;

  	int len;
	arr = PG_GETARG_ARRAYTYPE_P(0);
	arrElemType = ARR_ELEMTYPE(arr);

	get_typlenbyvalalign(arrElemType, &arrElemLen, &arrElemTypeByVal, &arrElemTypeAlignmentCode);
  
	deconstruct_array(arr, arrElemLen, arrElemLen, arrElemTypeByVal, arrElemTypeAlignmentCode,
	&arrd, &nullFlags, &len);

	if (len == 0) PG_RETURN_NULL();
	
	min = DatumGetInt16(arrd[0]);
	max = DatumGetInt16(arrd[0]);
	for (int i = 1; i < len; i++) {
		int value = DatumGetInt16(arrd[i]);
		if(value < min) {
			min = value;
		}
		if(value > max) {
			max = value;
		}
	}

	sprintf(result_str, "%d -> %d", min, max);

	PG_RETURN_CSTRING(result_str);
}
