CREATE OR REPLACE FUNCTION min_max_sfunc(anyelement, anyelement)
RETURNS anyelement
AS '$libdir/min_max_agg', 'min_max_sfunc'
LANGUAGE C IMMUTABLE STRICT;

DROP AGGREGATE IF EXISTS min_max(anyelement);
CREATE AGGREGATE min_max(anyelement) (
    SFUNC = min_max_sfunc,
    STYPE = anyelement
);

DO $$
DECLARE version_num integer;
BEGIN
  SELECT current_setting('server_version_num') INTO STRICT version_num;
  IF version_num > 90600 THEN
    EXECUTE $E$  ALTER FUNCTION min_max_sfunc(anyelement, anyelement) PARALLEL SAFE   $E$;

    EXECUTE $E$ DROP AGGREGATE IF EXISTS min_max(anyelement) $E$;
    EXECUTE $E$ CREATE AGGREGATE min_max(anyelement) (
        SFUNC = min_max_sfunc,
        STYPE = anyelement,
        COMBINEFUNC = min_max_sfunc,
        parallel = SAFE
    ); $E$;

  END IF;
END;
$$;
