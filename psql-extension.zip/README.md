Min Max
====================

### Installation
```
make install
```

### Usage

    % CREATE EXTENSION min_max_agg;
    CREATE EXTENSION

    % SELECT min_max(x) FROM (VALUES (1, 2, 3, 4, 5, 6, 7, 8, 9)) AS v(x);

### Tests

run `test/sql/agg.sql`
